#!/bin/sh

java -jar source-cleanup.jar $@
